README

To import terms into existing vocabularies druing installation, following steps have to be performed:

1. Export Terms with Taxonomy CSV module and settings:
    - CSV Format: First level parents
    - Vocabularies to export: select a voc...
    - Delimiter: , Comma
    - Value Enclosure: " Quotation Mark
    - Line Endings: Unix

2. Put the .csv file with naming <voc_machine_name>.csv under the folder taxonomy_import