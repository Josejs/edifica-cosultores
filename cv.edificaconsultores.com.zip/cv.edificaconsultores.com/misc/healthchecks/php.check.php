<?php
phpinfo(64);
